package com.example.myapplication2

import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.class2demo24.Model.Model
import com.example.class2demo24.Model.Student
import com.example.myapplication2.R

class AddStudentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_student)

        findViewById<View>(R.id.save_button).setOnClickListener {
            val name = "Name:"+  findViewById<EditText>(R.id.name_input).text.toString()
            val id =  "Id:"+findViewById<EditText>(R.id.id_input).text.toString()
            val newStudent = Student(name, id, "https://me.com/avatar.jpg", false)

            Model.instance.students.add(newStudent)
            finish()
        }
    }
}

